-- Lucky Luke's Eleven XI
-- Diesen Block vollständig im Supabase SQL Editor ausführen.

create table if not exists public.club_state (
  id integer primary key,
  version bigint not null default 0,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

insert into public.club_state (id, version, data, updated_at)
values (
  1,
  0,
  '{
    "version":0,
    "members":[],
    "applications":[],
    "sessions":[],
    "polls":[],
    "notices":[],
    "history":[],
    "lineup":{"starters":[],"bench":[],"slots":{},"autoSig":""},
    "adminAttendance":{},
    "updatedAt":0
  }'::jsonb,
  now()
)
on conflict (id) do nothing;

alter table public.club_state enable row level security;

drop policy if exists club_state_read on public.club_state;
drop policy if exists club_state_update on public.club_state;
drop policy if exists club_state_public_read on public.club_state;
drop policy if exists club_state_public_update on public.club_state;

create policy club_state_read
on public.club_state
for select
to anon
using (id = 1);

create policy club_state_update
on public.club_state
for update
to anon
using (id = 1)
with check (id = 1);

grant usage on schema public to anon;
grant select, update on public.club_state to anon;

select id, version, updated_at from public.club_state where id = 1;
