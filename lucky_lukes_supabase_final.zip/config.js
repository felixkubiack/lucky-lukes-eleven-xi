// Lucky Luke's Eleven XI – gemeinsamer Speicher
window.LLX_SUPABASE_URL = 'https://zxmxehqnbefdipvqszxh.supabase.co';

// HIER NUR NOCH den Supabase "anon public" bzw. "publishable" Key eintragen:
window.LLX_SUPABASE_ANON_KEY = 'HIER_DEINEN_PUBLIC_KEY_EINTRAGEN';

window.LLX_API_URL = '';
